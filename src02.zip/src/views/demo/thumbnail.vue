<template>
  <div>

    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
      <el-upload
        action="https://www.jizhangyl.com/jizhangyl/common/upload"
        list-type="picture-card"
        name='file'
        :on-success="handleAvatarSuccess"
        :on-preview="handlePictureCardPreview"
        :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible">
        <img width="100%" :src="dialogImageUrl" alt="">
      </el-dialog>
    </el-form>
    <el-button type="primary" @click="submitUpload()">确定</el-button>
  </div>
</template>

<script>
export default {
  data() {
      return {
        Imagelist: '',
        dialogImageUrl: '',
        dialogVisible: false,
        dataForm:[],
        providerId: '',
        imglist:[]
      };
    },
    activated () {
      this.providerId = this.$route.query.providerId || 0
    },
    methods: {

      handleAvatarSuccess(res, file) {
        this.dialogImageUrl = res.data;
        console.log(res.data);
        this.dataForm.push(this.dialogImageUrl);
        console.log(this.dataForm)
      },
      handleRemove(file, fileList) {
        console.log(file.response.data);
        this.dialogImageUrl = file.response.data;
        console.log('528');
        let index = this.dataForm.indexOf(this.dialogImageUrl);
        this.dataForm.splice(index,1);
        console.log(this.dataForm)
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      },
      //图片提交
      submitUpload () {
        console.log("提交图片");
        console.log(this);
        console.log(this.dialogImageUrl);
        let submitdata=[];
        for (let i = 0; i < this.dataForm.length; i++) {
          let objdata = new Object();
          objdata.imageUrl = this.dataForm[i];
          objdata.imageOrder = i + 1;
          submitdata.push(objdata);
          this.imglist = submitdata
        };
        console.log(JSON.stringify(this.imglist));
        this.$http({
          url: this.$http.adornUrl('/shop/detailImageUpload'),
          method: 'POST',
          data: this.$http.adornData({
            'productId':this.providerId,
            'productImages':JSON.stringify(this.imglist)
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.$message({
              message: '操作成功',
              type: 'success',
              duration: 1500,
              onClose: () => {
                this.visible = false
                this.$emit('refreshDataList')
              }
            })
          } else {
            this.$message.error(data.msg)
          }
        })
      },
    }
}
</script>
