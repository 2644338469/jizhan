<template>
	<div class="mod-demo-echarts">
		<el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
	      <el-form-item>
	        <el-date-picker
		      v-model="date1"
		      type="daterange"
		      align="right"
		      unlink-panels
		      value-format="yyyy-MM-dd HH:mm:ss"
		      range-separator="至"
		      start-placeholder="开始日期"
		      end-placeholder="结束日期">
	    	</el-date-picker>
		  </el-form-item>
		  <el-form-item>
		    <el-button type="primary" @click="searchBrandName()">查询</el-button>
		  </el-form-item>
	    </el-form>
	    <el-row :gutter="20">
	    	<el-col :span="24">
	    		<el-table
			      :data="allData"
			      border
			      
			      style="width: 100%;">
			      <el-table-column
			        prop="cost"
			        header-align="center"
			        align="center"
			        label="总货值">
			      </el-table-column>
			      <el-table-column
			        prop="taxes"
			        header-align="center"
			        align="center"
			        label="总关税">
			      </el-table-column>
			      <el-table-column
			        prop="costAndTaxes"
			        header-align="center"
			        align="center"
			        label="货值+关税">
			      </el-table-column>
			      <el-table-column
			        prop="freight"
			        header-align="center"
			        align="center"
			        label="总运费">
			      </el-table-column>
			      <el-table-column
			        prop="orderNums"
			        header-align="center"
			        align="center"
			        label="总订单数">
			      </el-table-column>
			      <el-table-column
			        prop="customerPrice"
			        header-align="center"
			        align="center"
			        label="全站客单价">
			      </el-table-column>
			    </el-table>
			    <el-row style="margin-top:15px;">
					<el-col :span="5" :offset="19"  style="text-align: right;"><el-button type="primary" @click="CustomsExportOrder()">订单导出</el-button></el-col>
				</el-row>
	    	</el-col>
	    	<el-col :span="12">
	    		<h3>商品</h3>
	    		<el-table
			      :data="dataShop"
			      border
			      style="width: 100%;">
			      <el-table-column header-align="center" label="商品销售额">
			      	<el-table-column
				        prop="dataShop.salesNum.shopName"
				        header-align="center"
				        align="center"
				        label="商品名称">
				      </el-table-column>
				      <el-table-column
				        prop="dataShop.salesNum.shopSalesNum"
				        header-align="center"
				        align="center"
				        label="销售额">
				      </el-table-column>
			      </el-table-column>
			      <el-table-column header-align="center" label="商品销量">
			      	<el-table-column
				        prop="dataShop.shopSales.shopName"
				        header-align="center"
				        align="center"
				        label="商品名称">
				    </el-table-column>
				    <el-table-column
				        prop="dataShop.shopSales.shopSales"
				        header-align="center"
				        align="center"
				        label="销量">
				    </el-table-column>
			      </el-table-column>
			    </el-table>
			    <el-row style="margin-top:15px;">
					<el-col :span="5" :offset="19"  style="text-align: right;"><el-button type="primary" @click="CustomsExportOrder()">订单导出</el-button></el-col>
				</el-row>
	    	</el-col>
	    	<el-col :span="12">
	    		<h3>买手</h3>
	    		<el-table
			      :data="dataBuyer"
			      border
			      style="width: 100%;">
			      <el-table-column header-align="center" label="买手销售额">
			      	<el-table-column
				        prop="dataBuyer.buyerSales.buyerName"
				        header-align="center"
				        align="center"
				        label="买手名称">
				      </el-table-column>
				      <el-table-column
				        prop="dataBuyer.buyerSales.buyerSales"
				        header-align="center"
				        align="center"
				        label="销售额">
				      </el-table-column>
			      </el-table-column>
			      <el-table-column header-align="center" label="买手订单数">
			      	<el-table-column
				        prop="dataBuyer.buyerOrdersNum.buyerName"
				        header-align="center"
				        align="center"
				        label="买手名称">
				    </el-table-column>
				    <el-table-column
				        prop="dataBuyer.buyerOrdersNum.buyerOrderNum"
				        header-align="center"
				        align="center"
				        label="订单数">
				    </el-table-column>
			      </el-table-column>
			    </el-table>
			    <el-row style="margin-top:15px;">
					<el-col :span="5" :offset="19"  style="text-align: right;"><el-button type="primary" @click="CustomsExportOrder()">订单导出</el-button></el-col>
				</el-row>
	    	</el-col>
	    </el-row>
	</div>
</template>

<script>
  export default {
    data () {
    	return {
    		allData:[
    		  {
    		  	cost: 6753.04,
		      	taxes: 605.76,           
		      	costAndTaxes: 7358.80,   
		      	freight: 666.00,    
		      	orderNums: 20,        
		      	customerPrice: 367.94 
    		  }
    		],
    		dataForm:"",
    		dataAllData:[],
    		dataShop:[],
    		dataBuyer:[],
    		date1:'',
    		dataListLoading:false
    	}
    },
    activated () {
      this.getDataList()
    },
    methods: {
      // 获取数据列表
      getDataList () {
        this.dataListLoading = true
        this.$http({
          url: this.$http.adornUrl('/count/fullSiteData'),
          method: 'get'
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.dataAllData = data.data.allData,
            this.dataShop = data.shop,
            this.dataBuyer = data.buyer
          } else {
            this.dataList = [],
            this.dataShop = [],
            this.dataBuyer = []
          }
          this.dataListLoading = false
        })
      }
  	}
  } 
</script>
<style>
  .el-date-editor .el-range-separator {
    width: 10% !important;
}
</style>
